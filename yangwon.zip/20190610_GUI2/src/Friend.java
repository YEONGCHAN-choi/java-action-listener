

public class Friend {
	private String[] data_arr;
	private String name;
	private int group;
	private String phone;
	private String email;
	private String profile;
	
	public Friend () {
	}

	public Friend (String[] new_data_arr) {
		this.data_arr = new_data_arr;
		if (data_arr.length == 4) {
			this.name = data_arr[0];
			this.group = Integer.parseInt(data_arr[1]);
			this.phone = data_arr[2];
			this.email = data_arr[3];
			this.profile = null;			
		} else if (data_arr.length == 5) {
			this.name = data_arr[0];
			this.group = Integer.parseInt(data_arr[1]);
			this.phone = data_arr[2];
			this.email = data_arr[3];
			this.profile = data_arr[4];			
		} else {
			System.out.println("ERROR : Wrong data input");
		}			
	}
	
	public void print() {
		if (this.profile == null) {
			System.out.println(this.name+" : "+this.group+" : "+this.phone+" : "+this.email+" : No Profile");
		} else {
			System.out.println(this.name+" : "+this.group+" : "+this.phone+" : "+this.email+" : "+this.profile);	
		}
	}	
	
	public String getName() {
		return this.name;
	}
	public int getGroup() {
		return this.group;
	}
	public String getPhone() {
		return this.phone;
	}
	public String getEmail() {
		return this.email;
	}
	public String getProfile() {
		return this.profile;
	}
}