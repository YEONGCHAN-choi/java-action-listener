import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelNames extends JPanel{
	private JLabel chkbox = new JLabel();
	private JLabel name = new JLabel("�̸�");
	private JLabel group = new JLabel("�׷�");
	private JLabel phone = new JLabel("��ȭ");
	private JLabel email = new JLabel("Email");
	private JLabel profile = new JLabel("����");
	
	//type : 0 > FrameFriendList �� �´� ���� / 1 > FrameFriendAdd �� �´� ����  
	public PanelNames(int type) {
		super(new GridLayout());
		
		name.setHorizontalAlignment(JLabel.CENTER);
		group.setHorizontalAlignment(JLabel.CENTER);
		phone.setHorizontalAlignment(JLabel.CENTER);
		email.setHorizontalAlignment(JLabel.CENTER);
		profile.setHorizontalAlignment(JLabel.CENTER);
		
		if (type == 0) {
			this.add(chkbox);	
		}
		this.add(name);
		this.add(group);
		this.add(phone);
		this.add(email);
		this.add(profile);
	}
}
