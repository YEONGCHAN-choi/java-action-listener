import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class FrameFriendList extends JFrame {	
	public PanelButtons buttons;
	public PanelTable tables;
	
	//FILE I/O
	FriendListFile fr_listFile;
	FriendList fr_list;
	
	//GridBagLayout ����
	private GridBagLayout grid;
	private GridBagConstraints con;	
	
	public FrameFriendList (String addr) {		
		grid = new GridBagLayout();
		con = new GridBagConstraints();
		this.setLayout(grid);
		
		//File I/O
		fr_listFile = new FriendListFile();
		FriendList fl = fr_listFile.readFileToList(addr);
		
		//ǥ �г�
		tables = new PanelTable(fl);
		addCom(tables, 0, 0, 1, 1, 2, 0, "HORIZONTAL");
		
		//4�� ���� ��ư ���� �г�
		buttons = new PanelButtons(fl, this);
		addCom(buttons, 1, 0, 1, 1, 1, 1, "BOTH");
		 
		this.setTitle("ģ�� ��� ����");
		this.setSize(800,400);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	//constraints ���� �� add
	private void addCom(Component c, int x, int y, int width, int height, int weight_x, int weight_y, String fill) {
		//��� ��ǥ�� ��ġ����
		con.gridx = x;
		con.gridy = y;
		//width, height > ��ĭ�̳� ��������
		con.gridwidth = width;
		con.gridheight = height;
		//weight ����
		con.weightx = weight_x;
		con.weighty = weight_y;
		//fill > weight �� ���� ä������ ����
		if (fill.equals("HORIZONTAL")) {
			con.fill = GridBagConstraints.HORIZONTAL;
		}else if (fill.equals("VERTICAL")) {
			con.fill = GridBagConstraints.VERTICAL;
		}else if (fill.equals("BOTH")) {
			con.fill = GridBagConstraints.BOTH;
		}
		
		grid.setConstraints(c, con);
		this.add(c);
	}
}
