import java.awt.GridLayout;
import javax.swing.*;

public class PanelFriend extends JPanel {
	private Friend friend;
	private JCheckBox chkbox;
	private JLabel name;
	private JTextField  group;
	private JTextField  phone;
	private JTextField  email;
	private JTextField  profile = new JTextField("");

	public PanelFriend (Friend new_friend) {
		super(new GridLayout()); //GridLayout �� ���빰�� ���� ũ�⸦ ������ ������
		this.friend = new_friend;
		
		this.chkbox = new JCheckBox();
		this.name = new JLabel(friend.getName());
		name.setHorizontalAlignment(JLabel.CENTER);
		this.group = new JTextField(String.valueOf(friend.getGroup()));
		this.phone = new JTextField(friend.getPhone());
		this.email = new JTextField(friend.getEmail());
		if(friend.getProfile() != null) {
			this.profile.setText(friend.getProfile());
		}
		
		this.add(chkbox);
		this.add(name);
		this.add(group);
		this.add(phone);
		this.add(email);
		this.add(profile);
	}	
}
