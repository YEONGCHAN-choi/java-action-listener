import java.util.ArrayList;
import java.util.regex.Pattern;

public class FriendList {
	private ArrayList<Friend> Fr_arrList;
	
	public FriendList () {
	}
	
	public FriendList (ArrayList<String> Read_file) {
		this.Fr_arrList = new ArrayList<Friend>();
		String[] line_split;
		int count = 0;
		
		for (int i=0; i<Read_file.size(); i++) {
			line_split = Read_file.get(i).split(":");
			//split �� ��̸� ��� Ʈ��
			for (int j=0; j<line_split.length; j++) {
				line_split[j] = line_split[j].trim();
			}
			//Valid üũ�� ����ϸ� �����ڷ� ����
			if (this.isValid(line_split)) {
				this.Fr_arrList.add(count, new Friend(line_split));		
				count++;
			}
		}
	}

// ���� �ʿ䰡 ���� ����(�ּ� + Invalid input) �� �ɷ����� �Լ�	
	private boolean isValid(String[] line_arr) {
//����, �ּ� üũ
		if (line_arr.length == 0 || line_arr[0].substring(0,2).equals("//")) {
			return false;
		}
//�������� üũ
		for (int i = 0; i < this.Fr_arrList.size(); i++) {
			if (line_arr[0].equals(this.Fr_arrList.get(i).getName())) {
				System.out.println("Invalid : Name Conflict");
				return false;
			}
		}		
//�̸� üũ
		if(!Pattern.matches("^[a-zA-Z]*$", line_arr[0])) {
			System.out.println("Invalid : Wrong Name");
			return false;
		}
//�׷� üũ
		if(!Pattern.matches("^[0-9]*$", line_arr[1])) {
			System.out.println("Invalid : Wrong Group");
			return false;
		}
//�̸��� üũ
		if (!line_arr[3].contains("@")) {
			System.out.println("Invalid : Wrong E-mail");
			return false;
		}
//length�� 5��� ���� üũ
		if (line_arr.length == 5) {
			if (!line_arr[4].contains(".")) {
				System.out.println("Invalid : Wrong Profile Image");
				return false;
			}
		}		
		return true;
	}	

	public int numFriends() {
		return this.Fr_arrList.size();
	}
	
	public void addFriend(String[] data_arr) {
		if (isValid(data_arr)) {
			this.Fr_arrList.add(new Friend(data_arr));
		} else {
			System.out.println("ERROR : Wrong Input");
		}
	}
	
	public Friend getFriend(int index) {
		return this.Fr_arrList.get(index);
	}
	
	public int getSize() {
		return this.Fr_arrList.size();
	}
	
}