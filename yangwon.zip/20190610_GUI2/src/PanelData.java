import java.awt.GridLayout;
import javax.swing.*;

public class PanelData extends JPanel {
	private JTextField name;
	private JTextField group;
	private JTextField phone;
	private JTextField email;
	private JTextField profile;
	
	public PanelData() {
		super(new GridLayout());
		
		name = new JTextField();
		group = new JTextField();
		phone = new JTextField();
		email = new JTextField();
		profile = new JTextField();
		
		this.add(name);
		this.add(group);
		this.add(phone);
		this.add(email);
		this.add(profile);			
	}
	
	public String[] getData() {
		if (profile.getText().equals("")) {
			String[] result = new String[4];
			result[0] = name.getText();
			result[1] = group.getText();
			result[2] = phone.getText();
			result[3] = email.getText();
			return result;
		} else {
			String[] result = new String[5];
			result[0] = name.getText();
			result[1] = group.getText();
			result[2] = phone.getText();
			result[3] = email.getText();
			result[4] = profile.getText();		
			return result;	
		}
	}
}
