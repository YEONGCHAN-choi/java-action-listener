import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FrameFriendAdd extends JFrame {	
	private JButton done_btn;
	private PanelNames names_pan;
	private PanelData data_pan;
	
	private GridBagLayout grid;
	private GridBagConstraints con;	
	
	private FriendList fr_list;
	private FrameFriendList mainFrame;
	
	public FrameFriendAdd(FriendList new_fl, FrameFriendList new_main) {
		this.fr_list = new_fl;
		this.mainFrame = new_main;
		
		grid = new GridBagLayout();
		con = new GridBagConstraints();
		this.setLayout(grid);
		
		names_pan = new PanelNames(1);
		addCom(names_pan, 0, 0, 1, 1, 6, 1, "BOTH");
		
		data_pan = new PanelData();
		addCom(data_pan, 0, 1, 1, 1, 6, 1, "BOTH");
		
		done_btn = new JButton("DONE");
		done_btn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("DONE");
				String[] data_arr = data_pan.getData();
				System.out.println(data_arr.length);
				fr_list.addFriend(data_arr);
				
				mainFrame.tables.drawList(fr_list);
				mainFrame.tables.revalidate();
				dispose();
			}
		});
		addCom(done_btn, 1, 0, 1, 2, 1, 1, "BOTH");
		
		this.setTitle("�߰��� ģ�� ����");
		this.setSize(700,150);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	//constraints ���� �� add
	private void addCom(Component c, int x, int y, int width, int height, int weight_x, int weight_y, String fill) {
		con.gridx = x;
		con.gridy = y;
		con.gridwidth = width;
		con.gridheight = height;
		con.weightx = weight_x;
		con.weighty = weight_y;
		
		if (fill.equals("HORIZONTAL")) {
			con.fill = GridBagConstraints.HORIZONTAL;
		}else if (fill.equals("VERTICAL")) {
			con.fill = GridBagConstraints.VERTICAL;
		}else if (fill.equals("BOTH")) {
			con.fill = GridBagConstraints.BOTH;
		}
		
		grid.setConstraints(c, con);
		this.add(c);
	}
}
