import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PanelButtons extends JPanel {
	JButton add_btn;
	JButton del_btn;
	JButton mod_btn;
	JButton sav_btn;
	
	FrameFriendList mainFrame;
	FriendList fl;
	
	public PanelButtons (FriendList new_fl, FrameFriendList new_main) {		
		super(new GridLayout(4,1));
		
		this.mainFrame = new_main;
		this.fl = new_fl;
		
		add_btn = new JButton("ADD");
		del_btn = new JButton("DELETE");
		mod_btn = new JButton("MODIFY");
		sav_btn = new JButton("SAVE FILE");
		
		add_btn.addActionListener(new InnerListener1());
		del_btn.addActionListener(new InnerListener1());
		mod_btn.addActionListener(new InnerListener1());
		sav_btn.addActionListener(new InnerListener1());
		
		this.add(add_btn);
		this.add(del_btn);
		this.add(mod_btn);
		this.add(sav_btn);		
	}

	//inner class > Listener
	class InnerListener1 implements ActionListener {
		FrameFriendList frame;
		public InnerListener1() {
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			//�׼� �̺�Ʈ �߻� > �Է� Ŀ��� Ȯ��
			switch(e.getActionCommand()) {
				case "ADD":
					System.out.println("ADD");
					FrameFriendAdd Ff_add = new FrameFriendAdd(fl, mainFrame);
					break;
				case "DELETE":
					System.out.println("DELETE");
					break;
				case "MODIFY":
					System.out.println("MODIFY");
					break;
				case "SAVE FILE":
					System.out.println("SAVE FILE");
					break;
			}			
		}	
	}
}
