public class Testing {	
	public static void main (String [] args) {
		FrameFriendList frame_fl = new FrameFriendList("friendlist-norm.data");		
	}	
}
